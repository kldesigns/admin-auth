<?php
include 'db_connect.php';

$entryid = intval($_POST['entryid']);
$verify = intval($_POST['updater']);

$sql = "UPDATE entries SET verified = $verify WHERE entryid = $entryid";

// Query
$mysqli->query($sql);
$resultcount = $mysqli->affected_rows;
if ($resultcount == 1){
    echo "OK";
} else {
    echo "error updating record" . $entryid . "verify".$verify." numrows ".$resultcount;
   // print_r($_POST);
}

?>
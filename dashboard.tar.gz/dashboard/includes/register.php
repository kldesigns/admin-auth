<?php
include_once 'functions.php';
$error_msg = $_GET['error_msg'];
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Viperty Admin User Registration</title>
<script type="text/JavaScript" src="../js/forms.js"></script>
<link rel="stylesheet" href="../css/pos.css" />
</head>
<body>
<!-- Registration form to be output if the POST variables are not
set or if the registration script caused an error. -->
<h1>Register a Backend User</h1>
<?php
if (!empty($error_msg)) { 
echo $error_msg;
}
?>
<ul>
<li>usernames must be an email address</li>
<li>Passwords must be at least 6 characters long</li>
<li>Passwords must contain
<ul>
<li>At least one upper case letter (A..Z)</li>
<li>At least one lower case letter (a..z)</li>
<li>At least one number (0..9)</li>
</ul>
</li>

</ul>
<form action="register.inc.php" method="post" name="registration_form">
Username (email) <input type='text' name='username' id='username' /><br>
Password: <input type="password"name="password" id="password"/><br>

<input type="submit" value="Register" name="register" /> 
</form>
<p>Return to the <a href="../login.php">login page</a>.</p>
</body>
</html>
<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // The host you want to connect to.
define("USER", "stan_pr");    // The database username. 
define("PASSWORD", "dRP6nEs!bvAuufzK");    // The database password. 
define("DATABASE", "stanhope");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // FALSE FOR DEVELOPMENT ONLY!!!!

<?php
include 'db_connect.php';

$whichquery = $_GET['query'];

if ($whichquery == "customers"){
    $sql = "SELECT firstName, lastName, mobile, email, gender, count(entryid) as entries, CASE WHEN marketing = '1' THEN 'Yes' ELSE 'No' END AS Marketing FROM customers LEFT JOIN entries ON customers.uid = entries.uid WHERE email <> '' GROUP BY customers.uid ORDER BY `lastName` ASC ";
}
if ($whichquery == "entries"){
    //$sql = "SELECT ADDTIME( STR_TO_DATE( CONCAT(LEFT(RIGHT(imgpath, 23),10), ' ', REPLACE(LEFT(RIGHT(imgpath, 12),8),'-', ':')), '%Y-%m-%d %T') , '0 10:0:0') AS DateTime, customers.firstName, customers.lastName, store, CONCAT('$ ', FORMAT( amount, 2)), school, CASE WHEN entries.verified = '1' THEN 'Verified' ELSE 'Unverified' END AS entries_verified, CONCAT('<a href=\"http://shopforyourschool.com.au/includes/', imgpath, '\" target=\"_blank\" onclick=\"window.open(&quot;http://shopforyourschool.com.au/includes/', imgpath, '&quot;, &quot;newwindow&quot;, &quot;width=600, height=800&quot;); return false;\">View Receipt</a>') FROM entries JOIN customers on entries.uid = customers.uid";
    $sql = "SELECT ADDTIME( STR_TO_DATE( CONCAT(LEFT(RIGHT(imgpath, 23),10), ' ', REPLACE(LEFT(RIGHT(imgpath, 12),8),'-', ':')), '%Y-%m-%d %T') , '0 10:0:0') AS DateTime, customers.firstName, customers.lastName, store, CONCAT('$ ', FORMAT( amount, 2)), school, CASE WHEN entries.verified = '1' THEN CONCAT('<input type=\"checkbox\" class=\"checks\" value = \"',`entryid`,'\" checked>') ELSE CONCAT('<input type=\"checkbox\" class=\"checks\" value = \"',`entryid`,'\">') END AS entries_verified, CONCAT('<a href=\"http://shopforyourschool.com.au/includes/', imgpath, '\" target=\"_blank\" onclick=\"window.open(&quot;http://shopforyourschool.com.au/includes/', imgpath, '&quot;, &quot;newwindow&quot;, &quot;width=600, height=800&quot;); return false;\">View Receipt</a>') FROM entries JOIN customers on entries.uid = customers.uid";
}
if ($whichquery == "leaderboard"){
    $sql = 'SELECT sid, CASE WHEN entries.school =  "St Josephs Primary School" THEN  "St Joseph'."'".'s Primary School" ELSE entries.school END AS school_name, CONCAT( "$ ", FORMAT(SUM( amount ), 2)) AS total_spend, Student_cnt, ROUND((SUM(amount) / Student_cnt ) *10, 1 ) AS points FROM entries JOIN Schools on entries.school = Schools.School GROUP BY entries.school ORDER BY points DESC';
}
if ($whichquery == "retailers"){
    $sql = 'SELECT store, CONCAT( "$ ", FORMAT(SUM( amount ), 2)) AS total_spend, COUNT( * ) AS total_entries FROM entries GROUP BY store ORDER BY total_spend DESC';
}
if ($whichquery == "winners"){
    $sql = 'SELECT winners.winnernumber, customers.firstName, customers.lastName, customers.gender, customers.mobile, customers.email, winners.drawtimedate FROM winners JOIN customers ON winners.uid = customers.uid WHERE winnernumber > 0 GROUP BY winners.uid';
}
if ($whichquery == "breakfast1"){
    $sql = 'SELECT DISTINCT cid, c_firstname, c_lastname, p_firstname, p_lastname FROM brk_santa_booking JOIN brk_santa_children ON brk_santa_booking.cid = brk_santa_children.id JOIN vip_santa_users ON brk_santa_booking.pid = vip_santa_users.id WHERE event_no = 1 AND waitlist = 0';
}
if ($whichquery == "breakfast2"){
    $sql = 'SELECT DISTINCT cid, c_firstname, c_lastname, p_firstname, p_lastname FROM brk_santa_booking JOIN brk_santa_children ON brk_santa_booking.cid = brk_santa_children.id JOIN vip_santa_users ON brk_santa_booking.pid = vip_santa_users.id WHERE event_no = 2 AND waitlist = 0';
}
if ($whichquery == "vipnight"){
    $sql = 'SELECT DISTINCT cid, c_firstname, c_lastname, p_firstname, p_lastname FROM vip_santa_booking JOIN vip_santa_children ON vip_santa_booking.cid = vip_santa_children.id JOIN vip_santa_users ON vip_santa_booking.pid = vip_santa_users.id WHERE ErrorOrDuplicate = 0';
}
if ($whichquery == "freedelivery"){
    $sql = 'SELECT  `p_firstname`, `p_lastname`, `uid`, `phone`, `address`, `suburb`,  `postcode`, `del_code`, `marketing`, `coles`, `fruitbarn`, `seafood`, `meat`, `chicken`, `bakers`, `patisserie`, `cake` FROM `fhd_users` WHERE cancelled = 0';
}




// Query
$result = $mysqli->query($sql);
$results = $result->fetch_all();
$counter = $mysqli->field_count;
$resultcount = $result->num_rows;
$returnJson = array();
foreach ($results as $row) {
$x = $counter - 1;
//getting columns
$column = array();
 while ($x >= 0){
        $column[$x]  = $row[$x];
        $x--;
    }
    array_push($returnJson, $column);
}
$constructed = array("draw"=>1, "recordsTotal"=> $resultcount, "recordsFiltered"=> $resultcount, "data"=> $returnJson, "defaultContent"=> "");

// Return a JSON parseable array
      echo json_encode($constructed);
?>
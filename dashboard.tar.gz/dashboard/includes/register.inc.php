<?php
include_once 'db_connect.php';
include_once 'functions.php';
 
$mid = $_POST['username'];
$password = $_POST['password'];

 // Create a random salt
 //$random_salt = hash('sha512', uniqid(openssl_random_pseudo_bytes(16), TRUE)); // Did not work
 $random_salt = $_SERVER['HTTP_USER_AGENT'];
 
 // Create salted password 
 $password .= $random_salt;
 $password = hash('sha512', $password);

 // Insert the new user into the database 
 // $firstname = $_POST['firstname'];
		// $lastname = $_POST['lastname'];
		if ($insert_stmt = $mysqli->prepare("INSERT INTO adminarea (username, password, salt) VALUES (?, ?, ?)")) {

 $insert_stmt->bind_param('sss', $mid, $password, $random_salt);
 // Execute the prepared query.
 if (!$insert_stmt->execute()) {
       $error_msg = "INSERT error";
       header('Location: register.php?error_msg='. $error_msg);
 } else {

 header('Location: register_success.php');
 }}
 ?>

<?php
include 'db_connect.php';

$winners = intval($_GET['count']);

$dt = new DateTime('NOW');
$datetime = $dt->format('Y-m-d H:i:s');

$sqlchecktable = "SHOW TABLES LIKE 'winners'";
$resultcheck = $mysqli->query($sqlchecktable);
$resultcheckcount = $resultcheck->num_rows;

if ($resultcheckcount != 1){

//copy entries table
    $sqlcreate = "CREATE TABLE winners LIKE entries"; 
    $mysqli->query($sqlcreate);
    $sqlinsert = "INSERT winners SELECT * FROM entries WHERE verified = 1";
    $mysqli->query($sqlinsert);

//add column for winner number and timedate stamp of draw
    $sqladdwinnercol = "ALTER TABLE winners ADD COLUMN winnernumber INT DEFAULT 0;";
    $mysqli->query($sqladdwinnercol);
    $sqladdtimestamp = "ALTER TABLE winners ADD drawtimedate DATETIME";
    $mysqli->query($sqladdtimestamp);

}

$sqlpickwinner = "SELECT uid from winners where winnernumber = 0 ORDER BY RAND() LIMIT 1";

//loop until winner limit reached
for ($x = 1; $x <= $winners; $x++) {
    $winnerresult = $mysqli->query($sqlpickwinner);
    while ($row = $winnerresult->fetch_assoc()){
        $uid = $row['uid'];
        $sqladdwinner = "UPDATE winners SET winnernumber = $x, drawtimedate = '$datetime' WHERE uid = $uid";
        $mysqli->query($sqladdwinner);
    }
}
//end loop
//select where winner number is not blank order by winnernumber
$sql = "SELECT ADDTIME( STR_TO_DATE( CONCAT(LEFT(RIGHT(imgpath, 23),10), ' ', REPLACE(LEFT(RIGHT(imgpath, 12),8),'-', ':')), '%Y-%m-%d %T') , '0 10:0:0') AS DateTime, customers.firstName, customers.lastName, store, CONCAT('$ ', FORMAT( amount, 2)), school, CASE WHEN winners.verified = '1' THEN CONCAT('<input type=\"checkbox\" class=\"checks\" value = \"',`entryid`,'\" checked>') ELSE CONCAT('<input type=\"checkbox\" class=\"checks\" value = \"',`entryid`,'\">') END AS entries_verified, CONCAT('<a href=\"http://shopforyourschool.com.au/includes/', imgpath, '\" target=\"_blank\" onclick=\"window.open(&quot;http://shopforyourschool.com.au/includes/', imgpath, '&quot;, &quot;newwindow&quot;, &quot;width=600, height=800&quot;); return false;\">View Receipt</a>'), winnernumber, drawtimedate FROM winners LEFT JOIN customers on winners.uid = customers.uid WHERE winnernumber > 0 GROUP BY winners.uid";

// Query
$result = $mysqli->query($sql);
$results = $result->fetch_all();
$counter = $mysqli->field_count;
$resultcount = $result->num_rows;
$returnJson = array();
foreach ($results as $row) {
$x = $counter - 1;
//getting columns
$column = array();
 while ($x >= 0){
        $column[$x]  = $row[$x];
        $x--;
    }
    array_push($returnJson, $column);
}
$constructed = array("draw"=>1, "recordsTotal"=> $resultcount, "recordsFiltered"=> $resultcount, "data"=> $returnJson, "defaultContent"=> "");

// Return a JSON parseable array
      echo json_encode($constructed);
?>
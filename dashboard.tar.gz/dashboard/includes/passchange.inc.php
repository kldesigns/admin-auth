<?php
include_once 'db_connect.php';
include_once 'functions.php';

//get posted values

 $mid = $_POST['mid'];
 $newpass = $_POST['password'];
 $confirmpass = $_POST['confirmpwd'];

 $lookupsalt = "SELECT salt FROM merchants WHERE mid = '$mid'";
 if ($lookupsaltstmt = $mysqli->prepare($lookupsalt)) {
 	$lookupsaltstmt->execute();
 	$lookupsaltstmt->bind_result($salt);
 	$lookupsaltstmt->fetch();
 	$lookupsaltstmt->close();
 	
 }
 if ($newpass == $confirmpass){
 $password = $mysqli->real_escape_string($newpass);
 $password .= $salt;
 $password = hash('sha512', $password);
 $updatepass = "UPDATE merchants SET password = '$password' WHERE mid = '$mid'";
 
 if ($mysqli->query($updatepass) === TRUE) {
	echo "Password updated successfully";
//next three lines only used for currently logged in user/merchant so that they remain logged in.
//	$user_browser = $_SERVER['HTTP_USER_AGENT'];
//	$password .= $user_browser;
//    $_SESSION['loginstring'] = hash('sha512', $password);
	
 } else {
 echo "A database error occurred updating your password. No update has occured.<br /> If this error persists, please contact support@viperty.com.";
}
} else {
	echo "Passwords did not match. Password not updated.";
}

 header('Location: ../vipertyadmin/passchange_success.php');
 
 ?>
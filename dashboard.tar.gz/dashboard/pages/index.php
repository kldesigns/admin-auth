<?php
include_once '../includes/db_connect.php';
include_once '../includes/functions.php';
 
sec_session_start();
//$this == true;
if(login_check($mysqli) == true) {
//if ($this == true){

//total spend, entries, entrants, schools
//Total Spend
$lookupspend = "SELECT FORMAT(SUM( amount ), 2) AS TotalSpend FROM entries WHERE verified = ?";
$totalspend = 0;
$verified = 1;
if ($totalspendresult = $mysqli->prepare($lookupspend)){
    $totalspendresult->bind_param('i',$verified);
    $totalspendresult->execute();
    $totalspendresult->bind_result($totalspend);
    $totalspendresult->fetch();
    $totalspendresult->free_result();
    $totalspendresult->close();
} //end spend
//Total Entries
$lookupentries = "SELECT COUNT(*) AS TotalEntries FROM entries WHERE verified = ?";
$totalentries = 0;
$verified = 1;
if ($totalentriesresult = $mysqli->prepare($lookupentries)){
    $totalentriesresult->bind_param('i',$verified);
    $totalentriesresult->execute();
    $totalentriesresult->bind_result($totalentries);
    $totalentriesresult->fetch();
    $totalentriesresult->free_result();
    $totalentriesresult->close();
} //end entries
//Total Customers
$lookupcustomers = "SELECT COUNT(*) AS TotalCustomers FROM customers WHERE email <> ''";
$totalcustomers = 0;
$verified = 1;
if ($totalcustomersresult = $mysqli->prepare($lookupcustomers)){
    $totalcustomersresult->bind_param('i',$verified);
    $totalcustomersresult->execute();
    $totalcustomersresult->bind_result($totalcustomers);
    $totalcustomersresult->fetch();
    $totalcustomersresult->free_result();
    $totalcustomersresult->close();
} //end customers
//leaderboard
    $x = 1;
    $leaderboardarray = array();
//$leaderboardsql = 'SELECT school, SUM(amount) AS entries_count FROM entries WHERE school <> "" GROUP BY school ORDER BY entries_count ASC';
$leaderboardsql = 'SELECT CASE WHEN SchoolCalc.school =  "St Josephs Primary School" THEN  "St Joseph'."'".'s Primary School" ELSE SchoolCalc.school END AS school_name, entries_count, Student_cnt, (entries_count/Student_cnt) AS points FROM ((SELECT school, SUM(amount) AS entries_count FROM entries WHERE school <> "" GROUP BY school) AS SchoolCalc) JOIN Schools ON Schools.School = SchoolCalc.school ORDER BY points ASC';
if ($leaderboardresult = $mysqli->query($leaderboardsql)){

    while ($leaderboardrow = $leaderboardresult->fetch_array(MYSQLI_ASSOC)) {
        $leaderboardarray['school'.$x] = $leaderboardrow['school_name'];
        $leaderboardarray['entries'.$x] = $leaderboardrow['points'];
        $x++;
    }
} //end leaderboard


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>VIPerty Campaigns Dashboard</title>

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../dist/css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Stanhope Village</a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
              
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="../includes/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href=""><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-table fa-fw"></i> Reports<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="entries.php#"> Entries</a>
                                </li>
                                <li>
                                    <a href="entrants.php#">Customers</a>
                                </li>
                                <li>
                                    <a href="schools.php#">Schools</a>
                                </li>
                                <li>
                                    <a href="retailers.php#">Retailers</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                         <li>
                            <a href="draw.php"><i class="fa fa-dashboard fa-fw"></i> Draw Winners</a>
                        </li>
                        <li>
                            <a href="winners.php"><i class="fa fa-dashboard fa-fw"></i> View Winners</a>
                        </li>
                        <li>
                            <a href="vipnight.php"><i class="fa fa-dashboard fa-fw"></i> VIP Night</a>
                        </li>
                        <li>
                            <a href="breakfast1.php"><i class="fa fa-dashboard fa-fw"></i> Breakfast Saturday</a>
                        </li>
                        <li>
                            <a href="breakfast2.php"><i class="fa fa-dashboard fa-fw"></i> Breakfast Sunday</a>
                        </li>
                         <li>
                            <a href="homedelivery.php"><i class="fa fa-dashboard fa-fw"></i> Home Delivery</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Shop For Your School 2015</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-list-alt fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $totalentries;?></div>
                                    <div>Total Entries</div>
                                </div>
                            </div>
                        </div>
                        <a href="entries.php#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-usd fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="large">$<?php echo $totalspend;?></div>
                                    <div>Total Spent</div>
                                </div>
                            </div>
                        </div>
                        <a href="entries.php#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $totalcustomers;?></div>
                                    <div>Registered Customers</div>
                                </div>
                            </div>
                        </div>
                        <a href="entrants.php#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-graduation-cap fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">10</div>
                                    <div>Schools Entered</div>
                                </div>
                            </div>
                        </div>
                        <a href="schools.php#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-list-ol fa-fw"></i> School Leaderboard
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Ranking</th>
                                            <th>School</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            while ($x > 0) {
                                                $z = $x;
                                            if ($leaderboardarray['school'.$x] == ""){
                                                $x--;
                                            } else {
                                                echo "<tr>";
                                                echo "<td>";
                                                if ($z == 10) {
                                                    echo "1st";
                                                } elseif ($z == 9){
                                                    echo "2nd";
                                                } elseif ($z == 8){
                                                    echo "3rd";
                                                } else {
                                                    $y = 10 - $z;
                                                    $y++;
                                                    echo $y. "th";
                                                }
                                                echo "</td><td>".$leaderboardarray['school'.$x]."</td></tr>";
                                                $x--;
                                            }   
                                            
                                            }
                                            
                                        ?>
                                        
                                    </tbody>
                                </table>
                                
                            </div>
                            <!-- /.list-group -->
                            <a href="schools.php##" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                    <!--
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> Donut Chart Example
                        </div>
                        <div class="panel-body">
                            <div id="morris-donut-chart"></div>
                            <a href="#" class="btn btn-default btn-block">View Details</a>
                        </div>
                        <!-- /.panel-body -->
                  <!--  </div> -->
                    <!-- /.panel -->
                    <!-- chat panel removed from here -->
                    <!-- /.panel .chat-panel -->
                </div>
                <!-- /.col-lg-4 -->
                
                <!-- /.col-lg-8 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="../bower_components/raphael/raphael-min.js"></script>
    <script src="../bower_components/morrisjs/morris.min.js"></script>
    <script src="../js/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
<?php
}else {      
    ?>
        <!doctype html>
<html>
<head>
    <title>VIPerty Admin Interface</title>

    <meta charset="utf-8" />
    <meta name="robots" content="noindex, nofollow, noarchive" />
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-touch-fullscreen" content="YES" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-transparent" />
    <link href="../css/pos.css" type="text/css" rel="stylesheet" media="screen"> 
    <!-- Turn off telephone number detection. -->
    <meta name = "format-detection" content = "telephone=no">
</head>

<body>
    
    <div id="container">
    
        <div id="topbar">
        
            <div class="fixedwidth">
                <div id="logodiv">
                    <img src="../images/VIPerty-Logo-WEB-trans.png" />  
                </div>
                <div id="posnav">
                    <ul>
                        <li></li>
                        <li><a href="../includes/logout.php">Log Out</a></li>
                    </ul>
                </div>         
            </div>  
            
        </div>
        
        <div id="main_content" class="fixedwidth">
			<p>
				You are not authorized to view this page, please login. <br>
				You will be redirected in 5 seconds. If not please <a href="../login.php">click here</a>
			</p>

    <?php    
        header ("refresh:5;url=../login.php");
}
?>

$(function() {

    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2010 Q1',
            Barnier: 2666,
            Hambledon: null,
            'John Palmer': 2647
        }, {
            period: '2010 Q2',
            Barnier: 2778,
            Hambledon: 2294,
            'John Palmer': 2441
        }, {
            period: '2010 Q3',
            Barnier: 4912,
            Hambledon: 1969,
            'John Palmer': 2501
        }, {
            period: '2010 Q4',
            Barnier: 3767,
            Hambledon: 3597,
            'John Palmer': 5689
        }, {
            period: '2011 Q1',
            Barnier: 6810,
            Hambledon: 1914,
            'John Palmer': 2293
        }, {
            period: '2011 Q2',
            Barnier: 5670,
            Hambledon: 4293,
            'John Palmer': 1881
        }, {
            period: '2011 Q3',
            Barnier: 4820,
            Hambledon: 3795,
            'John Palmer': 1588
        }, {
            period: '2011 Q4',
            Barnier: 15073,
            Hambledon: 5967,
            'John Palmer': 5175
        }, {
            period: '2012 Q1',
            Barnier: 10687,
            Hambledon: 4460,
            'John Palmer': 2028
        }, {
            period: '2012 Q2',
            Barnier: 8432,
            Hambledon: 5713,
            'John Palmer': 1791
        }],
        xkey: 'period',
        ykeys: ['Barnier', 'Hambledon', 'John Palmer'],
        labels: ['Barnier Public School', 'Hambledon Public School', 'John Palmer Public School'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Download Sales",
            value: 12
        }, {
            label: "In-Store Sales",
            value: 30
        }, {
            label: "Mail-Order Sales",
            value: 20
        }],
        resize: true
    });
`
    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: 'Barnier',
            a: 17
        }, {
            y: 'Hambledon',
            a: 74
        }, {
            y: 'Palmer',
            a: 52
        }, {
            y: 'Kellyville',
            a: 81
        }, {
            y: 'Parklea',
            a: 71
        }, {
            y: 'Quakers',
            a: 7
        }, {
            y: 'Riverbank',
            a: 64
        }, {
            y: 'Schofields',
            a: 38
        }, {
            y: 'StJoseph',
            a: 9
        }, {
            y: 'Tallowood',
            a: 17
        }],
        xkey: 'y',
        ykeys: ['a'],
        labels: ['Points'],
        hideHover: 'auto',
        resize: true
    });

});
